package com.example.dicerollingapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ResultsAdapter  extends RecyclerView.Adapter<ResultsAdapter.ResultsViewHolder> {
    private List<Results> mResults;
    private Context mContext;

    public ResultsAdapter(Context context, List<Results> results) {
        mContext = context;
        mResults = results;
    }

    @Override
    public ResultsAdapter.ResultsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.results_layout, parent, false);
        ResultsViewHolder viewHolder = new ResultsViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ResultsAdapter.ResultsViewHolder holder, int position) {
        holder.bindResults(mResults.get(position));
    }

    @Override
    public int getItemCount() {
        return mResults.size();
    }

    protected class ResultsViewHolder extends RecyclerView.ViewHolder{


        private Context mContext;
        private TextView diceTitle, diceResult1, diceResult2;

        public ResultsViewHolder(View itemView){
            super(itemView);
            diceTitle = itemView.findViewById(R.id.diceTitle);
            diceResult1 = itemView.findViewById(R.id.diceResult1);
            diceResult2 = itemView.findViewById(R.id.diceResult2);
            mContext = itemView.getContext();
        }

        @SuppressLint("SetTextI18n")
        public void bindResults(Results result) {
            if (result.getNoOfRolls() == 2){
                diceTitle.setText(result.getDiceType());
                diceResult1.setText("Result1: "+result.getResult1());
                diceResult1.setVisibility(View.VISIBLE);
                diceResult2.setText("Result2: "+result.getResult2());
                diceResult2.setVisibility(View.VISIBLE);
            }
            else {
                diceTitle.setText(result.getDiceType());
                diceResult1.setText("Result1: "+result.getResult1());
                diceResult1.setVisibility(View.VISIBLE);
            }
        }

    }
}