package com.example.dicerollingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.dicerollingapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding binding;

    Handler handler = new Handler();
    int count = 20;
    private final String defaultSelectedSide = "8";
    int noOfRoll = 1;
    int result1, result2;
    boolean useCustom = false;

    // for storing custom sides in shared preference
    SharedPreferences sharedPreferences;

    //A runnable that get executed after every 100 milliseconds as specified in roller() function and stops after 20 intervals
    // this is to help in rolling the dice randomly
    Runnable my_roller = new Runnable() {
        @SuppressLint("SetTextI18n")
        @Override
        public void run() {
            binding.diceText.setText(Integer.toString(getRandomInt(getNoOfSides())));

            // counter to check if the runnable has executed 20 intervals to stop
            count-=1;
            //calls the runnable to continue executing
            roller();

            //if count is zero stop the runnable, this is after 20 intervals
            if (count==0){
                count = 20;
                stop();

                //code to execute if the no of rolls made is 1
                if (noOfRoll == 1){
                    result1 = Integer.parseInt(binding.diceText.getText().toString());
                    binding.result1.setText("Result1: "+result1);
                    binding.result1.setVisibility(View.VISIBLE);
                    binding.result2.setVisibility(View.INVISIBLE);

                    //if number of rolls made are two, rerun the runnable to give second result
                    if (getNoOfRolls() == 2){
                        roller();
                        noOfRoll = 2;
                        return;
                    }
                    else{
                        Results result = new Results(getNoOfSides()+" SIDED DICE", getNoOfSides(), result1, 0, getNoOfRolls());
                        setRecyclerView();
                    }
                }
                //code to execute if number of dice rolls are two
                if (noOfRoll == 2){
                    result2 = Integer.parseInt(binding.diceText.getText().toString());
                    binding.result2.setText("Result2: "+result2);
                    binding.result2.setVisibility(View.VISIBLE);
                    Results result = new Results(getNoOfSides()+" SIDED DICE", getNoOfSides(), result1, result2, getNoOfRolls());
                    noOfRoll = 1;
                    setRecyclerView();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();

        sharedPreferences = this.getSharedPreferences("MySharedPref",MODE_PRIVATE);

        fillClassSpinner();

        binding.btnRollDice.setOnClickListener(this);
        binding.btnCustom.setOnClickListener(this);
        binding.btnSelect.setOnClickListener(this);

        setContentView(view);

        setRecyclerView();
    }

    public void roller(){
        handler.postDelayed(my_roller, 100);
    }

    public void stop() {
        handler.removeCallbacks(my_roller);
    }

    public int getRandomInt(int maxValue){
        return (int)(Math.random() * getNoOfSides()) + 1;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {

        if (v == binding.btnRollDice){

            binding.diceType.setText(getNoOfSides()+" SIDE DICE");
            roller();

        }

        // button to allow entering of custom sides
        if(v == binding.btnCustom){
            useCustom = true;
            binding.sidesSpinner.setVisibility(View.GONE);
            binding.sidesEdit.setVisibility(View.VISIBLE);
            binding.btnCustom.setVisibility(View.GONE);
            binding.btnSelect.setVisibility(View.VISIBLE);
        }

        //button to allow selection of predetermined dice sides
        if(v == binding.btnSelect){
            useCustom = false;
            binding.sidesSpinner.setVisibility(View.VISIBLE);
            binding.sidesEdit.setVisibility(View.GONE);
            binding.btnCustom.setVisibility(View.VISIBLE);
            binding.btnSelect.setVisibility(View.GONE);
        }

    }

    public void fillClassSpinner(){
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.sides_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.sidesSpinner.setAdapter(adapter);
        int defaultSelected = adapter.getPosition(defaultSelectedSide);
        binding.sidesSpinner.setSelection(defaultSelected);
    }

    public int getNoOfRolls(){
        if(binding.roll2RdBtn.isSelected() || binding.roll2RdBtn.isChecked()){
            return 2;
        }
        return 1;
    }

    //check if the user wants custom sides then get no of sides from the edit text else get no of sides from the spinner
    public int getNoOfSides(){
        if(useCustom){
            String sides = binding.sidesEdit.getText().toString();

            if (sides==null||sides.trim().isEmpty()) {
                binding.sidesEdit.setError("This field is required");
                return 4;
            }
            else {

                if (getSharedPreference("customSides") == null){
                    setSharedPreference(sides);
                }
                else {
                    String shSides = getSharedPreference("customSides") + ", "+ sides;
                    setSharedPreference(shSides);
                }

                return  Integer.parseInt(sides);
            }
        }
        else {
            return Integer.parseInt((String) binding.sidesSpinner.getSelectedItem());
        }
    }

    public void setRecyclerView(){
        ResultsAdapter adapter = new ResultsAdapter(MainActivity.this, Results.resultsList);
        binding.resultsList.setAdapter(adapter);
        binding.resultsList.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }

    public void setSharedPreference(String customSides){
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putString("customSides", customSides);

        //Store data persistently
        myEdit.apply();
    }

    public String getSharedPreference(String key){
        return sharedPreferences.getString(key, null);
    }
}