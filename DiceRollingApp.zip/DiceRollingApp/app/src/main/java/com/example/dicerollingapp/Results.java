package com.example.dicerollingapp;

import java.util.ArrayList;
import java.util.List;

public class Results {
    private String diceType;
    private int sides;
    private int result1;
    private int result2;
    private int noOfRolls;
    public static List<Results> resultsList = new ArrayList<>();

    public Results(String diceType, int sides, int result1, int result2, int noOfRolls) {
        this.diceType = diceType;
        this.sides = sides;
        this.result1 = result1;
        this.result2 = result2;
        this.noOfRolls = noOfRolls;
        resultsList.add(this);
    }

    public String getDiceType() {
        return diceType;
    }

    public void setDiceType(String diceType) {
        this.diceType = diceType;
    }

    public int getSides() {
        return sides;
    }

    public void setSides(int sides) {
        this.sides = sides;
    }

    public int getResult1() {
        return result1;
    }

    public void setResult1(int result1) {
        this.result1 = result1;
    }

    public int getResult2() {
        return result2;
    }

    public void setResult2(int result2) {
        this.result2 = result2;
    }

    public int getNoOfRolls() {
        return noOfRolls;
    }

    public void setNoOfRolls(int noOfRolls) {
        this.noOfRolls = noOfRolls;
    }
}
